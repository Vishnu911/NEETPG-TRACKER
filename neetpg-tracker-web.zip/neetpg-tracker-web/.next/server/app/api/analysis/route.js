(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[744],{5521:e=>{"use strict";e.exports=require("node:async_hooks")},5356:e=>{"use strict";e.exports=require("node:buffer")},7337:(e,t,a)=>{"use strict";a.r(t),a.d(t,{ComponentMod:()=>y,default:()=>E});var r,i={};a.r(i),a.d(i,{GET:()=>f,runtime:()=>p});var s={};a.r(s),a.d(s,{patchFetch:()=>h,routeModule:()=>m,serverHooks:()=>v,workAsyncStorage:()=>_,workUnitAsyncStorage:()=>g});var c=a(8621),o=a(8626),n=a(6680),l=a(1495),u=a(6368),d=a(7942);let p="edge";async function f(e){let t=e.env.DB;try{let e=`
      SELECT 
        s.id, 
        s.name, 
        COALESCE(SUM(r.correct), 0) as total_correct, 
        COALESCE(SUM(r.wrong), 0) as total_wrong
      FROM 
        subjects s
      LEFT JOIN 
        topics t ON s.id = t.subject_id
      LEFT JOIN 
        reviews r ON t.id = r.topic_id
      GROUP BY 
        s.id, s.name
      ORDER BY 
        s.display_order
    `,a=await t.prepare(e).all(),r=await t.prepare("SELECT * FROM settings").all(),i={};for(let e of r.results)i[e.key]=e.value;let s=new Date().toISOString().split("T")[0],c=`
      WITH topic_reviews AS (
        SELECT 
          t.id as topic_id,
          t.name as topic_name,
          s.id as subject_id,
          s.name as subject_name,
          COUNT(r.id) as total_reviews,
          MAX(r.review_date) as last_review_date,
          JULIANDAY('${s}') - JULIANDAY(MAX(r.review_date)) as days_since_last_review
        FROM 
          topics t
        JOIN 
          subjects s ON t.subject_id = s.id
        LEFT JOIN 
          reviews r ON t.id = r.topic_id
        GROUP BY 
          t.id, t.name, s.id, s.name
      )
      SELECT 
        *
      FROM 
        topic_reviews
      WHERE 
        (total_reviews = 1 AND days_since_last_review > ${i.review_threshold_1||20}) OR
        (total_reviews = 2 AND days_since_last_review > ${i.review_threshold_2||35}) OR
        (total_reviews = 3 AND days_since_last_review > ${i.review_threshold_3||50}) OR
        (total_reviews = 4 AND days_since_last_review > ${i.review_threshold_4||75}) OR
        (total_reviews = 5 AND days_since_last_review > ${i.review_threshold_5||90}) OR
        (total_reviews >= 6 AND days_since_last_review > ${i.review_threshold_6plus||120})
      ORDER BY 
        days_since_last_review DESC
    `,o=await t.prepare(c).all(),n=`
      WITH topic_accuracy AS (
        SELECT 
          t.id as topic_id,
          t.name as topic_name,
          s.id as subject_id,
          s.name as subject_name,
          SUM(r.correct) as total_correct,
          SUM(r.wrong) as total_wrong,
          CASE 
            WHEN SUM(r.correct) + SUM(r.wrong) = 0 THEN 0
            ELSE (SUM(r.correct) * 100.0 / (SUM(r.correct) + SUM(r.wrong)))
          END as accuracy
        FROM 
          topics t
        JOIN 
          subjects s ON t.subject_id = s.id
        LEFT JOIN 
          reviews r ON t.id = r.topic_id
        GROUP BY 
          t.id, t.name, s.id, s.name
        HAVING 
          SUM(r.correct) + SUM(r.wrong) > 0
      )
      SELECT 
        *
      FROM 
        topic_accuracy
      WHERE 
        accuracy < ${i.accuracy_threshold||85}
      ORDER BY 
        accuracy ASC
    `,l=await t.prepare(n).all();return Response.json({success:!0,analysis:{subjects:a.results,notFrequentlyRevised:o.results,lowAccuracy:l.results}})}catch(e){return console.error("Error fetching analysis data:",e),Response.json({success:!1,error:"Failed to fetch analysis data"},{status:500})}}let m=new l.AppRouteRouteModule({definition:{kind:u.A.APP_ROUTE,page:"/api/analysis/route",pathname:"/api/analysis",filename:"route",bundlePath:"app/api/analysis/route"},resolvedPagePath:"/home/ubuntu/neetpg-tracker-web/src/app/api/analysis/route.ts",nextConfigOutput:"",userland:i}),{workAsyncStorage:_,workUnitAsyncStorage:g,serverHooks:v}=m;function h(){return(0,d.V5)({workAsyncStorage:_,workUnitAsyncStorage:g})}let w=null==(r=self.__RSC_MANIFEST)?void 0:r["/api/analysis/route"],S=(e=>e?JSON.parse(e):void 0)(self.__RSC_SERVER_MANIFEST);w&&S&&(0,o.fQ)({page:"/api/analysis/route",clientReferenceManifest:w,serverActionsManifest:S,serverModuleMap:(0,c.e)({serverActionsManifest:S})});let y=s,E=n.s.wrap(m,{nextConfig:{env:{},webpack:null,eslint:{ignoreDuringBuilds:!0},typescript:{ignoreBuildErrors:!0,tsconfigPath:"tsconfig.json"},distDir:".next",cleanDistDir:!0,assetPrefix:"",cacheMaxMemorySize:0x3200000,configOrigin:"next.config.ts",useFileSystemPublicRoutes:!0,generateEtags:!0,pageExtensions:["tsx","ts","jsx","js"],poweredByHeader:!0,compress:!0,images:{deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[16,32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:60,formats:["image/webp"],dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",remotePatterns:[],unoptimized:!1},devIndicators:{appIsrStatus:!0,buildActivity:!0,buildActivityPosition:"bottom-right"},onDemandEntries:{maxInactiveAge:6e4,pagesBufferLength:5},amp:{canonicalBase:""},basePath:"",sassOptions:{},trailingSlash:!1,i18n:null,productionBrowserSourceMaps:!1,excludeDefaultMomentLocales:!0,serverRuntimeConfig:{},publicRuntimeConfig:{},reactProductionProfiling:!1,reactStrictMode:null,reactMaxHeadersLength:6e3,httpAgentOptions:{keepAlive:!0},logging:{},expireTime:31536e3,staticPageGenerationTimeout:60,modularizeImports:{"@mui/icons-material":{transform:"@mui/icons-material/{{member}}"},lodash:{transform:"lodash/{{member}}"}},outputFileTracingRoot:"/home/ubuntu/neetpg-tracker-web",experimental:{cacheLife:{default:{stale:300,revalidate:900,expire:0xfffffffe},seconds:{stale:0,revalidate:1,expire:60},minutes:{stale:300,revalidate:60,expire:3600},hours:{stale:300,revalidate:3600,expire:86400},days:{stale:300,revalidate:86400,expire:604800},weeks:{stale:300,revalidate:604800,expire:2592e3},max:{stale:300,revalidate:2592e3,expire:0xfffffffe}},cacheHandlers:{},cssChunking:!0,multiZoneDraftMode:!1,appNavFailHandling:!1,prerenderEarlyExit:!0,serverMinification:!0,serverSourceMaps:!1,linkNoTouchStart:!1,caseSensitiveRoutes:!1,clientSegmentCache:!1,preloadEntriesOnStart:!0,clientRouterFilter:!0,clientRouterFilterRedirects:!1,fetchCacheKeyPrefix:"",middlewarePrefetch:"flexible",optimisticClientCache:!0,manualClientBasePath:!1,cpus:3,memoryBasedWorkersCount:!1,imgOptConcurrency:null,imgOptTimeoutInSeconds:7,imgOptMaxInputPixels:0xfff8001,imgOptSequentialRead:null,isrFlushToDisk:!0,workerThreads:!1,optimizeCss:!1,nextScriptWorkers:!1,scrollRestoration:!1,externalDir:!1,disableOptimizedLoading:!1,gzipSize:!0,craCompat:!1,esmExternals:!0,fullySpecified:!1,swcTraceProfiling:!1,forceSwcTransforms:!1,largePageDataBytes:128e3,turbo:{root:"/home/ubuntu/neetpg-tracker-web"},typedRoutes:!1,typedEnv:!1,parallelServerCompiles:!1,parallelServerBuildTraces:!1,ppr:!1,authInterrupts:!1,reactOwnerStack:!1,webpackMemoryOptimizations:!1,optimizeServerReact:!0,useEarlyImport:!1,staleTimes:{dynamic:0,static:300},serverComponentsHmrCache:!0,staticGenerationMaxConcurrency:8,staticGenerationMinPagesPerWorker:25,dynamicIO:!1,inlineCss:!1,optimizePackageImports:["lucide-react","date-fns","lodash-es","ramda","antd","react-bootstrap","ahooks","@ant-design/icons","@headlessui/react","@headlessui-float/react","@heroicons/react/20/solid","@heroicons/react/24/solid","@heroicons/react/24/outline","@visx/visx","@tremor/react","rxjs","@mui/material","@mui/icons-material","recharts","react-use","effect","@effect/schema","@effect/platform","@effect/platform-node","@effect/platform-browser","@effect/platform-bun","@effect/sql","@effect/sql-mssql","@effect/sql-mysql2","@effect/sql-pg","@effect/sql-squlite-node","@effect/sql-squlite-bun","@effect/sql-squlite-wasm","@effect/sql-squlite-react-native","@effect/rpc","@effect/rpc-http","@effect/typeclass","@effect/experimental","@effect/opentelemetry","@material-ui/core","@material-ui/icons","@tabler/icons-react","mui-core","react-icons/ai","react-icons/bi","react-icons/bs","react-icons/cg","react-icons/ci","react-icons/di","react-icons/fa","react-icons/fa6","react-icons/fc","react-icons/fi","react-icons/gi","react-icons/go","react-icons/gr","react-icons/hi","react-icons/hi2","react-icons/im","react-icons/io","react-icons/io5","react-icons/lia","react-icons/lib","react-icons/lu","react-icons/md","react-icons/pi","react-icons/ri","react-icons/rx","react-icons/si","react-icons/sl","react-icons/tb","react-icons/tfi","react-icons/ti","react-icons/vsc","react-icons/wi"]},bundlePagesRouterDependencies:!1,configFile:"/home/ubuntu/neetpg-tracker-web/next.config.ts",configFileName:"next.config.ts"}})},5276:()=>{},2124:()=>{}},e=>{var t=t=>e(e.s=t);e.O(0,[847],()=>t(7337));var a=e.O();(_ENTRIES="undefined"==typeof _ENTRIES?{}:_ENTRIES)["middleware_app/api/analysis/route"]=a}]);
//# sourceMappingURL=route.js.map