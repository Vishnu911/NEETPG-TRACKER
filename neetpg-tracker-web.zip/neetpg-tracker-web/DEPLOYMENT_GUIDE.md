# NEETPG/INICET Exam Preparation Tracker - Deployment Guide

This guide will walk you through deploying your NEETPG/INICET Exam Preparation Tracker application to Vercel, a platform that offers free hosting for Next.js applications.

## Prerequisites

1. A GitHub account (https://github.com/signup)
2. A Vercel account (you can sign up with your GitHub account at https://vercel.com/signup)

## Step 1: Prepare Your GitHub Repository

1. Log in to your GitHub account
2. Click the "+" icon in the top-right corner and select "New repository"
3. Name your repository (e.g., "neetpg-tracker")
4. Choose "Private" if you want to keep your code private, or "Public" if you don't mind it being visible
5. Click "Create repository"

## Step 2: Upload the Code to GitHub

Option A: Using GitHub Web Interface
1. In your new repository, click "uploading an existing file"
2. Drag and drop the zip file contents or select them from your computer
3. Commit the changes

Option B: Using Git Command Line (for advanced users)
1. Extract the zip file to a folder on your computer
2. Open a terminal/command prompt in that folder
3. Run the following commands:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
   git push -u origin main
   ```

## Step 3: Deploy to Vercel

1. Go to https://vercel.com/ and log in with your GitHub account
2. Click "Add New..." and select "Project"
3. Find and select your GitHub repository from the list
4. Vercel will automatically detect that it's a Next.js project
5. Configure your project:
   - Project Name: Choose a name (e.g., "neetpg-tracker")
   - Framework Preset: Next.js (should be auto-detected)
   - Root Directory: ./
   - Build Command: Leave as default
   - Output Directory: Leave as default
6. Click "Deploy"

Vercel will now build and deploy your application. This process usually takes 1-2 minutes.

## Step 4: Set Up the Database

Once deployed, you'll need to set up the database:

1. In your Vercel dashboard, select your project
2. Go to the "Storage" tab
3. Click "Connect Database" and select "Vercel Postgres" (or "Vercel KV" if you prefer)
4. Follow the prompts to create a new database
5. Once created, go to the "Settings" tab of your database
6. Find the "Connection String" and copy it
7. Go back to your project settings
8. Go to the "Environment Variables" section
9. Add a new environment variable:
   - Name: DATABASE_URL
   - Value: Paste the connection string you copied
10. Click "Save"
11. Trigger a new deployment by clicking "Redeploy" in your project dashboard

## Step 5: Initialize the Database

1. In your Vercel dashboard, go to your project
2. Click on "Deployments" and then on your latest deployment
3. Click on "Functions" tab
4. Find the "/api/init" function and click on it
5. Click "Test Function" with a POST request
6. This will initialize your database with the required tables and seed data

## Step 6: Access Your Application

Your application is now deployed and ready to use! You can access it at the URL provided by Vercel, which will look something like:

https://your-project-name.vercel.app

## Additional Information

### Custom Domain

If you want to use a custom domain:
1. Go to your project settings in Vercel
2. Click on "Domains"
3. Add your domain and follow the instructions to configure DNS settings

### Updating Your Application

When you want to update your application:
1. Make changes to your code locally
2. Commit and push the changes to GitHub
3. Vercel will automatically deploy the new version

### Troubleshooting

If you encounter any issues:
1. Check the "Deployments" section in Vercel to see build logs
2. Ensure your environment variables are correctly set
3. Check that your database is properly connected

For more help, visit Vercel's documentation at https://vercel.com/docs

## Using Your Application

1. When you first access your application, you'll need to initialize the database by clicking the "Initialize Database" button on the subjects page
2. You can then navigate through subjects, add topics, and track your reviews
3. Use the analysis page to monitor your progress and identify areas that need more attention

Enjoy using your NEETPG/INICET Exam Preparation Tracker!
