# NEETPG/INICET Exam Preparation Tracker

A web application to track your NEETPG/INICET exam preparation progress across all 19 subjects.

## Features

- **Subject Management**: Track all 19 subjects in one place
- **Topic Tracking**: Record correct and wrong answers for each topic
- **Review History**: Keep a history of all your reviews with dates
- **Analysis Dashboard**: 
  - Visual representation of your performance across subjects
  - Identification of topics that need revision based on customizable thresholds
  - List of topics with accuracy below 85%

## Getting Started

### Prerequisites

- Node.js 18+ (recommended)
- npm or pnpm

### Installation

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   # or
   pnpm install
   ```
3. Run the development server:
   ```
   npm run dev
   # or
   pnpm dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser

### Database Setup

The application uses a SQL database to store your progress. To initialize the database:

1. Start the development server
2. Navigate to the Subjects page
3. Click "Initialize Database" if no subjects are shown

## Usage Guide

### Tracking Your Reviews

1. Navigate to a subject from the Subjects page
2. Select a topic to review
3. Enter the number of correct and wrong answers
4. Add the review date (defaults to today)
5. Click "Save Review"

### Analysis Features

The Analysis page provides three key insights:

1. **Subject Performance**: Shows your accuracy across all subjects with a pie chart visualization
2. **Not Frequently Revised Topics**: Identifies topics that need revision based on these thresholds:
   - If total reviews = 1, Last review must be < 20 days ago
   - If total reviews = 2, last review must be < 35 days ago
   - If total reviews = 3, last review must be < 50 days ago
   - If total reviews = 4, last review must be < 75 days ago
   - If total reviews = 5, last review must be < 90 days ago
   - If total reviews ≥ 6, last review must be < 120 days ago
3. **Topics with Accuracy < 85%**: Lists topics where your accuracy is below 85%

## Deployment

See the [Deployment Guide](DEPLOYMENT_GUIDE.md) for instructions on deploying to Vercel.

## Technology Stack

- **Frontend**: Next.js, React, Tailwind CSS
- **Visualization**: D3.js
- **Database**: SQL (via D1 on Vercel)

## License

This project is for personal use only.

## Acknowledgements

Created for NEETPG/INICET exam preparation tracking.
