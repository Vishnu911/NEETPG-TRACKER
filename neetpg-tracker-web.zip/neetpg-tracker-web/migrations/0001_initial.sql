-- Migration number: 0001        2025-04-04T12:57:00.000Z
-- NEETPG/INICET Exam Preparation Tracker Database Schema

-- Drop existing tables if they exist
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS topics;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS settings;

-- Create subjects table
CREATE TABLE IF NOT EXISTS subjects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  display_order INTEGER NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create topics table
CREATE TABLE IF NOT EXISTS topics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  mcqids TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  topic_id INTEGER NOT NULL,
  correct INTEGER NOT NULL DEFAULT 0,
  wrong INTEGER NOT NULL DEFAULT 0,
  review_date DATE NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

-- Create settings table for application configuration
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX idx_topics_subject_id ON topics(subject_id);
CREATE INDEX idx_reviews_topic_id ON reviews(topic_id);
CREATE INDEX idx_reviews_review_date ON reviews(review_date);

-- Insert default settings
INSERT INTO settings (key, value) VALUES 
  ('last_backup', ''),
  ('review_threshold_1', '20'),  -- If total reviews = 1, Last review must be < 20 days ago
  ('review_threshold_2', '35'),  -- If total reviews = 2, last review must be < 35 days ago
  ('review_threshold_3', '50'),  -- If total reviews = 3, last review must be < 50 days ago
  ('review_threshold_4', '75'),  -- If total reviews = 4, last review must be < 75 days ago
  ('review_threshold_5', '90'),  -- If total reviews = 5, last review must be < 90 days ago
  ('review_threshold_6plus', '120'), -- If total reviews ≥ 6, last review must be < 120 days ago
  ('accuracy_threshold', '85');  -- Threshold for low accuracy topics (85%)
