'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import PieChart from '../../components/PieChart';

export default function AnalysisClient() {
  const [analysisData, setAnalysisData] = useState({
    subjects: [],
    notFrequentlyRevised: [],
    lowAccuracy: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchAnalysisData() {
      try {
        setLoading(true);
        const response = await fetch('/api/analysis');
        if (!response.ok) {
          throw new Error('Failed to fetch analysis data');
        }
        const data = await response.json();
        if (data.success) {
          setAnalysisData(data.analysis);
        } else {
          throw new Error(data.error || 'Failed to fetch analysis data');
        }
      } catch (err) {
        console.error('Error fetching analysis data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchAnalysisData();
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading analysis data...</div>;
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 my-4">
        Error: {error}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-blue-800">Analysis Dashboard</h1>

      <section className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <h2 className="text-xl font-semibold text-blue-800">Subject Performance</h2>
        </div>
        <div className="p-6">
          {analysisData.subjects.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Subject
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Correct
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Wrong
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Accuracy
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {analysisData.subjects.map((subject) => {
                    const accuracy = subject.total_correct + subject.total_wrong > 0 
                      ? (subject.total_correct / (subject.total_correct + subject.total_wrong)) * 100 
                      : 0;
                    
                    return (
                      <tr key={subject.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Link 
                            href={`/subjects/${subject.id}`}
                            className="text-blue-600 hover:text-blue-900 font-medium"
                          >
                            {subject.name}
                          </Link>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                          {subject.total_correct}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                          {subject.total_wrong}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <div className="flex items-center">
                            <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                              <div 
                                className={`h-2.5 rounded-full ${
                                  accuracy >= 85 ? 'bg-green-600' : 
                                  accuracy >= 70 ? 'bg-yellow-500' : 'bg-red-600'
                                }`}
                                style={{ width: `${accuracy}%` }}
                              ></div>
                            </div>
                            <span>{accuracy.toFixed(1)}%</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No subject performance data available yet. Start tracking your reviews to see statistics.
            </div>
          )}
          
          <div className="mt-8">
            {analysisData.subjects.length > 0 ? (
              <PieChart data={analysisData.subjects} width={600} height={400} />
            ) : (
              <div className="p-4 bg-gray-50 rounded-lg text-center text-gray-500">
                Add review data to see the subject accuracy distribution chart
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <h2 className="text-xl font-semibold text-blue-800">Not Frequently Revised Topics</h2>
        </div>
        <div className="p-6">
          {analysisData.notFrequentlyRevised.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Topic
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Subject
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total Reviews
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Last Review
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Days Since
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {analysisData.notFrequentlyRevised.map((topic) => (
                    <tr key={topic.topic_id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Link 
                          href={`/topics/${topic.topic_id}`}
                          className="text-blue-600 hover:text-blue-900 font-medium"
                        >
                          {topic.topic_name}
                        </Link>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {topic.subject_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {topic.total_reviews}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {topic.last_review_date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                        {topic.days_since_last_review}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No topics need revision at this time.
            </div>
          )}
        </div>
      </section>

      <section className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <h2 className="text-xl font-semibold text-blue-800">Topics with Accuracy &lt; 85%</h2>
        </div>
        <div className="p-6">
          {analysisData.lowAccuracy.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Topic
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Subject
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Correct
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Wrong
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Accuracy
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {analysisData.lowAccuracy.map((topic) => (
                    <tr key={topic.topic_id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Link 
                          href={`/topics/${topic.topic_id}`}
                          className="text-blue-600 hover:text-blue-900 font-medium"
                        >
                          {topic.topic_name}
                        </Link>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {topic.subject_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                        {topic.total_correct}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                        {topic.total_wrong}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center">
                          <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                            <div 
                              className={`h-2.5 rounded-full ${
                                topic.accuracy >= 70 ? 'bg-yellow-500' : 'bg-red-600'
                              }`}
                              style={{ width: `${topic.accuracy}%` }}
                            ></div>
                          </div>
                          <span>{topic.accuracy.toFixed(1)}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No topics with accuracy below 85%.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
