import { Suspense } from 'react';
import AnalysisClient from './analysis-client';

export default function AnalysisPage() {
  return (
    <Suspense fallback={<div>Loading analysis data...</div>}>
      <AnalysisClient />
    </Suspense>
  );
}
