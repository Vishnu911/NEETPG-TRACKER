import { type NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const db = request.env.DB;

  try {
    // Get analysis data
    
    // 1. Get all subjects with their total correct and wrong reviews
    const subjectsQuery = `
      SELECT 
        s.id, 
        s.name, 
        COALESCE(SUM(r.correct), 0) as total_correct, 
        COALESCE(SUM(r.wrong), 0) as total_wrong
      FROM 
        subjects s
      LEFT JOIN 
        topics t ON s.id = t.subject_id
      LEFT JOIN 
        reviews r ON t.id = r.topic_id
      GROUP BY 
        s.id, s.name
      ORDER BY 
        s.display_order
    `;
    
    const subjectsResult = await db.prepare(subjectsQuery).all();
    
    // 2. Get not frequently revised topics based on thresholds
    const settings = await db.prepare('SELECT * FROM settings').all();
    const settingsMap = {};
    for (const row of settings.results as {key: string, value: string}[]) {
      settingsMap[row.key] = row.value;
    }
    
    const currentDate = new Date().toISOString().split('T')[0];
    
    const notFrequentlyRevisedQuery = `
      WITH topic_reviews AS (
        SELECT 
          t.id as topic_id,
          t.name as topic_name,
          s.id as subject_id,
          s.name as subject_name,
          COUNT(r.id) as total_reviews,
          MAX(r.review_date) as last_review_date,
          JULIANDAY('${currentDate}') - JULIANDAY(MAX(r.review_date)) as days_since_last_review
        FROM 
          topics t
        JOIN 
          subjects s ON t.subject_id = s.id
        LEFT JOIN 
          reviews r ON t.id = r.topic_id
        GROUP BY 
          t.id, t.name, s.id, s.name
      )
      SELECT 
        *
      FROM 
        topic_reviews
      WHERE 
        (total_reviews = 1 AND days_since_last_review > ${settingsMap['review_threshold_1'] || 20}) OR
        (total_reviews = 2 AND days_since_last_review > ${settingsMap['review_threshold_2'] || 35}) OR
        (total_reviews = 3 AND days_since_last_review > ${settingsMap['review_threshold_3'] || 50}) OR
        (total_reviews = 4 AND days_since_last_review > ${settingsMap['review_threshold_4'] || 75}) OR
        (total_reviews = 5 AND days_since_last_review > ${settingsMap['review_threshold_5'] || 90}) OR
        (total_reviews >= 6 AND days_since_last_review > ${settingsMap['review_threshold_6plus'] || 120})
      ORDER BY 
        days_since_last_review DESC
    `;
    
    const notFrequentlyRevisedResult = await db.prepare(notFrequentlyRevisedQuery).all();
    
    // 3. Get topics with accuracy < 85%
    const lowAccuracyQuery = `
      WITH topic_accuracy AS (
        SELECT 
          t.id as topic_id,
          t.name as topic_name,
          s.id as subject_id,
          s.name as subject_name,
          SUM(r.correct) as total_correct,
          SUM(r.wrong) as total_wrong,
          CASE 
            WHEN SUM(r.correct) + SUM(r.wrong) = 0 THEN 0
            ELSE (SUM(r.correct) * 100.0 / (SUM(r.correct) + SUM(r.wrong)))
          END as accuracy
        FROM 
          topics t
        JOIN 
          subjects s ON t.subject_id = s.id
        LEFT JOIN 
          reviews r ON t.id = r.topic_id
        GROUP BY 
          t.id, t.name, s.id, s.name
        HAVING 
          SUM(r.correct) + SUM(r.wrong) > 0
      )
      SELECT 
        *
      FROM 
        topic_accuracy
      WHERE 
        accuracy < ${settingsMap['accuracy_threshold'] || 85}
      ORDER BY 
        accuracy ASC
    `;
    
    const lowAccuracyResult = await db.prepare(lowAccuracyQuery).all();
    
    return Response.json({ 
      success: true, 
      analysis: {
        subjects: subjectsResult.results,
        notFrequentlyRevised: notFrequentlyRevisedResult.results,
        lowAccuracy: lowAccuracyResult.results
      }
    });
  } catch (error) {
    console.error('Error fetching analysis data:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to fetch analysis data' 
    }, { status: 500 });
  }
}
