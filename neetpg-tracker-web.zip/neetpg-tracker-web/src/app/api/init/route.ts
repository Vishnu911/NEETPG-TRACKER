import { type NextRequest } from 'next/server';
import { seedDatabase } from '../../../lib/database';

export const runtime = 'edge';

export async function POST(request: NextRequest) {
  const db = request.env.DB;
  
  try {
    // Seed the database with initial data
    await seedDatabase(db);
    
    return Response.json({ 
      success: true, 
      message: 'Database initialized successfully' 
    });
  } catch (error) {
    console.error('Error initializing database:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to initialize database' 
    }, { status: 500 });
  }
}
