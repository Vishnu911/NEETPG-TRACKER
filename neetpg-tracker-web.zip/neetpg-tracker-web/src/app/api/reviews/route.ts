import { type NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const topicId = searchParams.get('topicId');
  const db = request.env.DB;

  if (!topicId) {
    return Response.json({ 
      success: false, 
      error: 'Topic ID is required' 
    }, { status: 400 });
  }

  try {
    // Get reviews for the specified topic
    const result = await db.prepare(
      'SELECT * FROM reviews WHERE topic_id = ? ORDER BY review_date DESC'
    ).bind(topicId).all();
    
    return Response.json({ 
      success: true, 
      reviews: result.results 
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to fetch reviews' 
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const db = request.env.DB;
  
  try {
    const { topicId, correct, wrong, reviewDate } = await request.json();
    
    if (!topicId || correct === undefined || wrong === undefined || !reviewDate) {
      return Response.json({ 
        success: false, 
        error: 'Missing required fields' 
      }, { status: 400 });
    }
    
    // Add a new review
    await db.prepare(
      'INSERT INTO reviews (topic_id, correct, wrong, review_date) VALUES (?, ?, ?, ?)'
    ).bind(topicId, correct, wrong, reviewDate).run();
    
    return Response.json({ 
      success: true, 
      message: 'Review added successfully' 
    });
  } catch (error) {
    console.error('Error adding review:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to add review' 
    }, { status: 500 });
  }
}
