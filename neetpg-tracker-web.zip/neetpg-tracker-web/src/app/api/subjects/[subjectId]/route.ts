import { type NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest, { params }: { params: { subjectId: string } }) {
  const subjectId = params.subjectId;
  const db = request.env.DB;

  try {
    // Get subject details
    const result = await db.prepare(
      'SELECT * FROM subjects WHERE id = ?'
    ).bind(subjectId).first();
    
    if (!result) {
      return Response.json({ 
        success: false, 
        error: 'Subject not found' 
      }, { status: 404 });
    }
    
    return Response.json({ 
      success: true, 
      subject: result 
    });
  } catch (error) {
    console.error('Error fetching subject:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to fetch subject' 
    }, { status: 500 });
  }
}
