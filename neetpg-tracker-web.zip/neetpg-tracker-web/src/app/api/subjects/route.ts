import { type NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const db = request.env.DB;

  try {
    // Get all subjects
    const result = await db.prepare('SELECT * FROM subjects ORDER BY display_order').all();
    
    return Response.json({ 
      success: true, 
      subjects: result.results 
    });
  } catch (error) {
    console.error('Error fetching subjects:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to fetch subjects' 
    }, { status: 500 });
  }
}
