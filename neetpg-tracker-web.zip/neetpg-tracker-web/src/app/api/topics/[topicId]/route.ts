import { type NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest, { params }: { params: { topicId: string } }) {
  const topicId = params.topicId;
  const db = request.env.DB;

  try {
    // Get topic details
    const result = await db.prepare(
      'SELECT * FROM topics WHERE id = ?'
    ).bind(topicId).first();
    
    if (!result) {
      return Response.json({ 
        success: false, 
        error: 'Topic not found' 
      }, { status: 404 });
    }
    
    return Response.json({ 
      success: true, 
      topic: result 
    });
  } catch (error) {
    console.error('Error fetching topic:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to fetch topic' 
    }, { status: 500 });
  }
}
