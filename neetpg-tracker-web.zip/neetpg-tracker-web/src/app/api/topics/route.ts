import { type NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const subjectId = searchParams.get('subjectId');
  const db = request.env.DB;

  if (!subjectId) {
    return Response.json({ 
      success: false, 
      error: 'Subject ID is required' 
    }, { status: 400 });
  }

  try {
    // Get topics for the specified subject
    const result = await db.prepare(
      'SELECT * FROM topics WHERE subject_id = ? ORDER BY id'
    ).bind(subjectId).all();
    
    return Response.json({ 
      success: true, 
      topics: result.results 
    });
  } catch (error) {
    console.error('Error fetching topics:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to fetch topics' 
    }, { status: 500 });
  }
}
