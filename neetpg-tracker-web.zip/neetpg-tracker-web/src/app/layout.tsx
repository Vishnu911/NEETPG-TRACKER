import { Suspense } from 'react';
import Link from 'next/link';

export const metadata = {
  title: 'NEETPG/INICET Exam Preparation Tracker',
  description: 'Track your NEETPG/INICET exam preparation progress',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen bg-gray-50">
          <header className="bg-blue-800 text-white shadow-md">
            <div className="container mx-auto px-4 py-4">
              <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold">
                  <Link href="/">NEETPG/INICET Tracker</Link>
                </h1>
                <nav>
                  <ul className="flex space-x-6">
                    <li>
                      <Link href="/" className="hover:text-blue-200">
                        Dashboard
                      </Link>
                    </li>
                    <li>
                      <Link href="/subjects" className="hover:text-blue-200">
                        Subjects
                      </Link>
                    </li>
                    <li>
                      <Link href="/analysis" className="hover:text-blue-200">
                        Analysis
                      </Link>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </header>
          <main className="container mx-auto px-4 py-8">
            <Suspense fallback={<div>Loading...</div>}>
              {children}
            </Suspense>
          </main>
          <footer className="bg-gray-100 border-t border-gray-200 py-6">
            <div className="container mx-auto px-4 text-center text-gray-600">
              <p>NEETPG/INICET Exam Preparation Tracker &copy; {new Date().getFullYear()}</p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
