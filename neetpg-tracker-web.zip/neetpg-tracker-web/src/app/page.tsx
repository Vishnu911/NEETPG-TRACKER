import { Suspense } from 'react';
import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="space-y-8">
      <section className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-blue-800 mb-4">
          NEETPG/INICET Exam Preparation Tracker
        </h1>
        <p className="text-lg text-gray-700 mb-6">
          Welcome to your personalized exam preparation tracker. This tool helps you monitor your progress
          across all 19 subjects, identify topics that need more attention, and optimize your study strategy.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link 
            href="/subjects" 
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg text-center transition-colors"
          >
            Browse Subjects
          </Link>
          <Link 
            href="/analysis" 
            className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg text-center transition-colors"
          >
            View Analysis
          </Link>
        </div>
      </section>

      <section className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-blue-800 mb-4">How to Use This Tracker</h2>
        <div className="space-y-4">
          <div className="border-l-4 border-blue-500 pl-4">
            <h3 className="font-semibold text-lg">1. Track Your Reviews</h3>
            <p className="text-gray-700">
              For each topic you review, record whether your answers were correct or incorrect.
              This helps build a comprehensive picture of your strengths and weaknesses.
            </p>
          </div>
          
          <div className="border-l-4 border-blue-500 pl-4">
            <h3 className="font-semibold text-lg">2. Monitor Frequency</h3>
            <p className="text-gray-700">
              The system automatically flags topics that haven't been reviewed recently enough
              based on spaced repetition principles.
            </p>
          </div>
          
          <div className="border-l-4 border-blue-500 pl-4">
            <h3 className="font-semibold text-lg">3. Focus on Weak Areas</h3>
            <p className="text-gray-700">
              The analysis page highlights topics with accuracy below 85%, helping you
              prioritize areas that need more attention.
            </p>
          </div>
          
          <div className="border-l-4 border-blue-500 pl-4">
            <h3 className="font-semibold text-lg">4. Track Overall Progress</h3>
            <p className="text-gray-700">
              Visualize your performance across all 19 subjects with the accuracy distribution
              chart to maintain a balanced study approach.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-blue-800 mb-4">Quick Stats</h2>
        <Suspense fallback={<div>Loading stats...</div>}>
          <div className="text-center py-8">
            <p className="text-gray-600">
              Start tracking your reviews to see your statistics here!
            </p>
          </div>
        </Suspense>
      </section>
    </div>
  );
}
