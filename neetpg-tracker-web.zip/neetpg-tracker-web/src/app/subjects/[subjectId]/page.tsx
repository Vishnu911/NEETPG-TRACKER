import { Suspense } from 'react';
import TopicsClient from './topics-client';

export default function SubjectTopicsPage({ params }: { params: { subjectId: string } }) {
  return (
    <Suspense fallback={<div>Loading subject details...</div>}>
      <TopicsClient subjectId={params.subjectId} />
    </Suspense>
  );
}
