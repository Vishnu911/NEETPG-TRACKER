'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function TopicsClient({ subjectId }) {
  const [subject, setSubject] = useState(null);
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        
        // Fetch subject details
        const subjectResponse = await fetch(`/api/subjects/${subjectId}`);
        if (!subjectResponse.ok) {
          throw new Error('Failed to fetch subject details');
        }
        const subjectData = await subjectResponse.json();
        if (!subjectData.success) {
          throw new Error(subjectData.error || 'Failed to fetch subject details');
        }
        setSubject(subjectData.subject);
        
        // Fetch topics for this subject
        const topicsResponse = await fetch(`/api/topics?subjectId=${subjectId}`);
        if (!topicsResponse.ok) {
          throw new Error('Failed to fetch topics');
        }
        const topicsData = await topicsResponse.json();
        if (!topicsData.success) {
          throw new Error(topicsData.error || 'Failed to fetch topics');
        }
        setTopics(topicsData.topics);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    if (subjectId) {
      fetchData();
    }
  }, [subjectId]);

  const handleTopicClick = (topicId) => {
    router.push(`/topics/${topicId}`);
  };

  if (loading) {
    return <div className="text-center py-8">Loading topics...</div>;
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 my-4">
        Error: {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/subjects" className="text-blue-600 hover:text-blue-800">
            ← Back to Subjects
          </Link>
          <h1 className="text-3xl font-bold text-blue-800 mt-2">
            {subject ? subject.name : 'Subject Details'}
          </h1>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <h2 className="text-xl font-semibold text-blue-800">Topics</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {topics.length > 0 ? (
            topics.map((topic) => (
              <div 
                key={topic.id} 
                className="p-4 hover:bg-gray-50 cursor-pointer"
                onClick={() => handleTopicClick(topic.id)}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium text-gray-900">{topic.name}</h3>
                    {topic.mcqids && (
                      <p className="text-sm text-gray-500">MCQIDS: {topic.mcqids}</p>
                    )}
                  </div>
                  <div className="text-blue-600">
                    View Details →
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-gray-500">
              No topics found for this subject.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
