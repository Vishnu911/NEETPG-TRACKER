import { Suspense } from 'react';
import SubjectsClient from './subjects-client';

export default function SubjectsPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-blue-800">Subjects</h1>
      </div>

      <Suspense fallback={<div>Loading subjects...</div>}>
        <SubjectsClient />
      </Suspense>
    </div>
  );
}
