'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function SubjectsClient() {
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();

  useEffect(() => {
    async function fetchSubjects() {
      try {
        const response = await fetch('/api/subjects');
        if (!response.ok) {
          throw new Error('Failed to fetch subjects');
        }
        const data = await response.json();
        if (data.success) {
          setSubjects(data.subjects);
        } else {
          throw new Error(data.error || 'Failed to fetch subjects');
        }
      } catch (err) {
        console.error('Error fetching subjects:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchSubjects();
  }, []);

  const handleSubjectClick = (subjectId) => {
    router.push(`/subjects/${subjectId}`);
  };

  if (loading) {
    return <div className="text-center py-8">Loading subjects...</div>;
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 my-4">
        Error: {error}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {subjects.length > 0 ? (
        subjects.map((subject) => (
          <div
            key={subject.id}
            onClick={() => handleSubjectClick(subject.id)}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
          >
            <h2 className="text-xl font-semibold text-blue-700">{subject.name}</h2>
            <div className="mt-4 text-sm text-gray-500">
              Click to view topics
            </div>
          </div>
        ))
      ) : (
        <div className="col-span-3 text-center py-8 text-gray-500">
          No subjects found. Initialize the database to get started.
          <div className="mt-4">
            <button
              onClick={async () => {
                try {
                  setLoading(true);
                  const response = await fetch('/api/init', {
                    method: 'POST',
                  });
                  if (!response.ok) {
                    throw new Error('Failed to initialize database');
                  }
                  const data = await response.json();
                  if (data.success) {
                    // Refresh the page to show the subjects
                    window.location.reload();
                  } else {
                    throw new Error(data.error || 'Failed to initialize database');
                  }
                } catch (err) {
                  console.error('Error initializing database:', err);
                  setError(err.message);
                } finally {
                  setLoading(false);
                }
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm transition-colors"
            >
              Initialize Database
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
