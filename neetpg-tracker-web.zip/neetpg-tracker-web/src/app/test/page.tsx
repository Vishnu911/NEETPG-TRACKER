'use client';

import { useState } from 'react';
import { runAllTests } from '../../lib/test-utils';

export default function TestPage() {
  const [testResults, setTestResults] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runTests = async () => {
    setIsRunning(true);
    setTestResults(['Starting tests...']);

    // Override console.log to capture test output
    const originalLog = console.log;
    const originalError = console.error;
    
    console.log = (message) => {
      originalLog(message);
      setTestResults(prev => [...prev, message]);
    };
    
    console.error = (message) => {
      originalError(message);
      setTestResults(prev => [...prev, `ERROR: ${message}`]);
    };

    try {
      await runAllTests();
    } catch (error) {
      console.error(`Test execution error: ${error.message}`);
    } finally {
      // Restore console functions
      console.log = originalLog;
      console.error = originalError;
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-blue-800">Application Testing</h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="mb-4 text-gray-700">
          This page allows you to run automated tests to verify the functionality of the NEETPG/INICET tracker application.
          The tests will check database initialization, API endpoints, and core functionality.
        </p>
        
        <button
          onClick={runTests}
          disabled={isRunning}
          className={`${
            isRunning ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'
          } text-white font-semibold py-2 px-4 rounded-md shadow-sm transition-colors`}
        >
          {isRunning ? 'Running Tests...' : 'Run Tests'}
        </button>
      </div>

      {testResults.length > 0 && (
        <div className="bg-black rounded-lg shadow-md overflow-hidden">
          <div className="p-4 bg-gray-800 border-b border-gray-700">
            <h2 className="text-xl font-semibold text-white">Test Results</h2>
          </div>
          <div className="p-4 max-h-96 overflow-y-auto">
            <pre className="text-green-400 font-mono text-sm whitespace-pre-wrap">
              {testResults.join('\n')}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
