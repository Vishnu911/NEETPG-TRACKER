import { Suspense } from 'react';
import TopicClient from './topic-client';

export default function TopicPage({ params }: { params: { topicId: string } }) {
  return (
    <Suspense fallback={<div>Loading topic details...</div>}>
      <TopicClient topicId={params.topicId} />
    </Suspense>
  );
}
