'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function TopicClient({ topicId }) {
  const [topic, setTopic] = useState(null);
  const [subject, setSubject] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    correct: 0,
    wrong: 0,
    review_date: new Date().toISOString().split('T')[0]
  });
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();

  // Calculate statistics
  const totalCorrect = reviews.reduce((sum, review) => sum + review.correct, 0);
  const totalWrong = reviews.reduce((sum, review) => sum + review.wrong, 0);
  const totalReviews = totalCorrect + totalWrong;
  const accuracy = totalReviews > 0 ? (totalCorrect / totalReviews) * 100 : 0;

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        
        // Fetch topic details
        const topicResponse = await fetch(`/api/topics/${topicId}`);
        if (!topicResponse.ok) {
          throw new Error('Failed to fetch topic details');
        }
        const topicData = await topicResponse.json();
        if (!topicData.success) {
          throw new Error(topicData.error || 'Failed to fetch topic details');
        }
        setTopic(topicData.topic);
        
        // Fetch subject details
        const subjectResponse = await fetch(`/api/subjects/${topicData.topic.subject_id}`);
        if (!subjectResponse.ok) {
          throw new Error('Failed to fetch subject details');
        }
        const subjectData = await subjectResponse.json();
        if (!subjectData.success) {
          throw new Error(subjectData.error || 'Failed to fetch subject details');
        }
        setSubject(subjectData.subject);
        
        // Fetch reviews for this topic
        const reviewsResponse = await fetch(`/api/reviews?topicId=${topicId}`);
        if (!reviewsResponse.ok) {
          throw new Error('Failed to fetch reviews');
        }
        const reviewsData = await reviewsResponse.json();
        if (!reviewsData.success) {
          throw new Error(reviewsData.error || 'Failed to fetch reviews');
        }
        setReviews(reviewsData.reviews);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    if (topicId) {
      fetchData();
    }
  }, [topicId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: name === 'review_date' ? value : parseInt(value, 10) || 0
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setSubmitting(true);
      
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          topicId: parseInt(topicId, 10),
          correct: formData.correct,
          wrong: formData.wrong,
          reviewDate: formData.review_date
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to add review');
      }
      
      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to add review');
      }
      
      // Reset form
      setFormData({
        correct: 0,
        wrong: 0,
        review_date: new Date().toISOString().split('T')[0]
      });
      
      // Refresh reviews
      const reviewsResponse = await fetch(`/api/reviews?topicId=${topicId}`);
      const reviewsData = await reviewsResponse.json();
      if (reviewsData.success) {
        setReviews(reviewsData.reviews);
      }
      
    } catch (err) {
      console.error('Error adding review:', err);
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading topic details...</div>;
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 my-4">
        Error: {error}
      </div>
    );
  }

  if (!topic || !subject) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-lg p-4 my-4">
        Topic or subject not found
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <Link href={`/subjects/${subject.id}`} className="text-blue-600 hover:text-blue-800">
          ← Back to {subject.name}
        </Link>
        <h1 className="text-3xl font-bold text-blue-800 mt-2">{topic.name}</h1>
        {topic.mcqids && (
          <p className="text-gray-600">MCQIDS: {topic.mcqids}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-blue-800 mb-4">Statistics</h2>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-500">Total Reviews</p>
              <p className="text-2xl font-bold">{totalReviews}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Correct</p>
              <p className="text-2xl font-bold text-green-600">{totalCorrect}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Wrong</p>
              <p className="text-2xl font-bold text-red-600">{totalWrong}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Accuracy</p>
              <p className="text-2xl font-bold text-blue-600">{accuracy.toFixed(2)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 md:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-blue-800">Add Review</h2>
          </div>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="correct" className="block text-sm font-medium text-gray-700 mb-1">
                  Correct Answers
                </label>
                <input
                  type="number"
                  id="correct"
                  name="correct"
                  min="0"
                  value={formData.correct}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="0"
                />
              </div>
              <div>
                <label htmlFor="wrong" className="block text-sm font-medium text-gray-700 mb-1">
                  Wrong Answers
                </label>
                <input
                  type="number"
                  id="wrong"
                  name="wrong"
                  min="0"
                  value={formData.wrong}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="0"
                />
              </div>
            </div>
            <div>
              <label htmlFor="review_date" className="block text-sm font-medium text-gray-700 mb-1">
                Review Date
              </label>
              <input
                type="date"
                id="review_date"
                name="review_date"
                value={formData.review_date}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className={`w-full ${
                submitting ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'
              } text-white font-semibold py-2 px-4 rounded-md shadow-sm transition-colors`}
            >
              {submitting ? 'Saving...' : 'Save Review'}
            </button>
          </form>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <h2 className="text-xl font-semibold text-blue-800">Review History</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {reviews.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Correct
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Wrong
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Accuracy
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {reviews.map((review) => {
                    const reviewTotal = review.correct + review.wrong;
                    const reviewAccuracy = reviewTotal > 0 ? (review.correct / reviewTotal) * 100 : 0;
                    
                    return (
                      <tr key={review.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {review.review_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                          {review.correct}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                          {review.wrong}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {reviewAccuracy.toFixed(2)}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-4 text-center text-gray-500">
              No review history found for this topic.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
