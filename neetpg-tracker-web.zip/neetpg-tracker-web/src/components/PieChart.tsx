import { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface PieChartProps {
  data: {
    id: number;
    name: string;
    total_correct: number;
    total_wrong: number;
  }[];
  width?: number;
  height?: number;
}

export default function PieChart({ data, width = 400, height = 400 }: PieChartProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!data || data.length === 0 || !svgRef.current) return;

    // Clear any existing chart
    d3.select(svgRef.current).selectAll('*').remove();

    // Calculate accuracy for each subject
    const chartData = data.map(subject => {
      const total = subject.total_correct + subject.total_wrong;
      const accuracy = total > 0 ? (subject.total_correct / total) * 100 : 0;
      return {
        name: subject.name,
        value: accuracy,
        total: total
      };
    });

    // Filter out subjects with no reviews
    const filteredData = chartData.filter(d => d.total > 0);

    // If no data after filtering, show a message
    if (filteredData.length === 0) {
      const svg = d3.select(svgRef.current);
      svg.append('text')
        .attr('x', width / 2)
        .attr('y', height / 2)
        .attr('text-anchor', 'middle')
        .style('font-size', '14px')
        .style('fill', '#666')
        .text('No data available yet');
      return;
    }

    // Set up dimensions
    const margin = 40;
    const radius = Math.min(width, height) / 2 - margin;

    // Create SVG
    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${width / 2}, ${height / 2})`);

    // Set up color scale
    const color = d3.scaleOrdinal()
      .domain(filteredData.map(d => d.name))
      .range(d3.schemeCategory10);

    // Set up pie generator
    const pie = d3.pie<any>()
      .value(d => d.value)
      .sort(null);

    // Set up arc generator
    const arc = d3.arc()
      .innerRadius(0)
      .outerRadius(radius);

    // Set up outer arc for labels
    const outerArc = d3.arc()
      .innerRadius(radius * 1.1)
      .outerRadius(radius * 1.1);

    // Generate pie chart
    const arcs = svg.selectAll('.arc')
      .data(pie(filteredData))
      .enter()
      .append('g')
      .attr('class', 'arc');

    // Add path (slice)
    arcs.append('path')
      .attr('d', arc as any)
      .attr('fill', d => color(d.data.name) as string)
      .attr('stroke', 'white')
      .style('stroke-width', '2px')
      .style('opacity', 0.8);

    // Add labels
    arcs.append('text')
      .attr('transform', d => {
        const pos = outerArc.centroid(d as any);
        const midAngle = d.startAngle + (d.endAngle - d.startAngle) / 2;
        pos[0] = radius * 0.95 * (midAngle < Math.PI ? 1 : -1);
        return `translate(${pos})`;
      })
      .attr('dy', '.35em')
      .style('text-anchor', d => {
        const midAngle = d.startAngle + (d.endAngle - d.startAngle) / 2;
        return midAngle < Math.PI ? 'start' : 'end';
      })
      .style('font-size', '12px')
      .text(d => `${d.data.name} (${d.data.value.toFixed(1)}%)`);

    // Add polylines between slices and labels
    arcs.append('polyline')
      .attr('stroke', 'black')
      .style('fill', 'none')
      .style('stroke-width', '1px')
      .attr('points', d => {
        const pos = outerArc.centroid(d as any);
        const midAngle = d.startAngle + (d.endAngle - d.startAngle) / 2;
        pos[0] = radius * 0.95 * (midAngle < Math.PI ? 1 : -1);
        return [arc.centroid(d as any), outerArc.centroid(d as any), pos];
      });

    // Add title
    svg.append('text')
      .attr('x', 0)
      .attr('y', -height / 2 + 20)
      .attr('text-anchor', 'middle')
      .style('font-size', '16px')
      .style('font-weight', 'bold')
      .text('Subject Accuracy Distribution');

  }, [data, width, height]);

  return (
    <div className="flex justify-center">
      <svg ref={svgRef} width={width} height={height}></svg>
    </div>
  );
}
