import { Subject } from '../lib/database';

// List of subjects from the Excel file
export const subjects: Omit<Subject, 'id'>[] = [
  { name: "ANATOMY", display_order: 1 },
  { name: "PHYSIOLOGY", display_order: 2 },
  { name: "BIOCHEMISTRY", display_order: 3 },
  { name: "PATHOLOGY", display_order: 4 },
  { name: "MICROBIOLOGY", display_order: 5 },
  { name: "PHARMACOLOGY", display_order: 6 },
  { name: "OPTHALMOLOGY", display_order: 7 },
  { name: "ENT", display_order: 8 },
  { name: "COMMED", display_order: 9 },
  { name: "FORENSIC MED", display_order: 10 },
  { name: "MEDICINE", display_order: 11 },
  { name: "SURGERY", display_order: 12 },
  { name: "OBG", display_order: 13 },
  { name: "PEDIATRICS", display_order: 14 },
  { name: "ORTHOPEDICS", display_order: 15 },
  { name: "ANESTHESIOLOGY", display_order: 16 },
  { name: "RADIOLOGY", display_order: 17 },
  { name: "DERMATOLOGY", display_order: 18 },
  { name: "PSYCHIATRY", display_order: 19 }
];
