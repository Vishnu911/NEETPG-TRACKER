import fs from 'fs';
import path from 'path';

// Define the topic structure
export type TopicData = {
  subject: string;
  name: string;
  mcqids: string;
};

// Parse the JSON data from the Excel analysis
const subjectsDataPath = path.join(process.cwd(), 'subjects_data.json');
const subjectsData = JSON.parse(fs.readFileSync(subjectsDataPath, 'utf8'));

// Create a flattened array of topics
export const topics: TopicData[] = [];

// Process each subject
Object.entries(subjectsData).forEach(([subject, data]: [string, any]) => {
  // Get topics from the sample_topics array
  const subjectTopics = data.sample_topics || [];
  
  // Add each topic to the flattened array
  subjectTopics.forEach((topic: any) => {
    topics.push({
      subject,
      name: topic['Topic name'] || '',
      mcqids: topic['MCQIDS'] || ''
    });
  });
  
  // For subjects with placeholder topics (A, B, C)
  if (subjectTopics.length === 0 || 
      (subjectTopics.length === 1 && subjectTopics[0]['Topic name'] === 'No topics available')) {
    // Add placeholder topics
    ['A', 'B', 'C'].forEach(placeholder => {
      topics.push({
        subject,
        name: placeholder,
        mcqids: ''
      });
    });
  }
});

// Export the topics array
export default topics;
