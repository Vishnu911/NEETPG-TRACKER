import { subjects } from '../data/subjects';
import { topics } from '../data/topics';

export type Subject = {
  id: number;
  name: string;
  display_order: number;
};

export type Topic = {
  id: number;
  subject_id: number;
  name: string;
  mcqids: string;
};

export type Review = {
  id: number;
  topic_id: number;
  correct: number;
  wrong: number;
  review_date: string;
};

export type Settings = {
  [key: string]: string;
};

// Function to seed the database with initial data
export async function seedDatabase(db: D1Database) {
  console.log('Seeding database with initial data...');
  
  // Insert subjects
  for (const subject of subjects) {
    await db.prepare(
      'INSERT INTO subjects (name, display_order) VALUES (?, ?)'
    ).bind(subject.name, subject.display_order).run();
  }
  
  // Get all subjects to get their IDs
  const subjectsResult = await db.prepare('SELECT * FROM subjects').all();
  const subjectMap = new Map<string, number>();
  
  for (const subject of subjectsResult.results as Subject[]) {
    subjectMap.set(subject.name, subject.id);
  }
  
  // Insert topics
  for (const topic of topics) {
    const subjectId = subjectMap.get(topic.subject);
    if (subjectId) {
      await db.prepare(
        'INSERT INTO topics (subject_id, name, mcqids) VALUES (?, ?, ?)'
      ).bind(subjectId, topic.name, topic.mcqids || '').run();
    }
  }
  
  console.log('Database seeding completed');
}

// Function to get all subjects
export async function getSubjects(db: D1Database): Promise<Subject[]> {
  const result = await db.prepare(
    'SELECT * FROM subjects ORDER BY display_order'
  ).all();
  return result.results as Subject[];
}

// Function to get topics for a subject
export async function getTopicsBySubject(db: D1Database, subjectId: number): Promise<Topic[]> {
  const result = await db.prepare(
    'SELECT * FROM topics WHERE subject_id = ? ORDER BY id'
  ).bind(subjectId).all();
  return result.results as Topic[];
}

// Function to get all reviews for a topic
export async function getReviewsByTopic(db: D1Database, topicId: number): Promise<Review[]> {
  const result = await db.prepare(
    'SELECT * FROM reviews WHERE topic_id = ? ORDER BY review_date DESC'
  ).bind(topicId).all();
  return result.results as Review[];
}

// Function to add a new review
export async function addReview(
  db: D1Database, 
  topicId: number, 
  correct: number, 
  wrong: number, 
  reviewDate: string
): Promise<void> {
  await db.prepare(
    'INSERT INTO reviews (topic_id, correct, wrong, review_date) VALUES (?, ?, ?, ?)'
  ).bind(topicId, correct, wrong, reviewDate).run();
}

// Function to get settings
export async function getSettings(db: D1Database): Promise<Settings> {
  const result = await db.prepare('SELECT * FROM settings').all();
  const settings: Settings = {};
  for (const row of result.results as {key: string, value: string}[]) {
    settings[row.key] = row.value;
  }
  return settings;
}

// Function to update a setting
export async function updateSetting(db: D1Database, key: string, value: string): Promise<void> {
  await db.prepare(
    'UPDATE settings SET value = ? WHERE key = ?'
  ).bind(value, key).run();
}

// Function to get not frequently revised topics
export async function getNotFrequentlyRevisedTopics(db: D1Database): Promise<any[]> {
  // This is a complex query that needs to be implemented based on the thresholds
  // For now, we'll return a placeholder
  return [];
}

// Function to get topics with accuracy below threshold
export async function getLowAccuracyTopics(db: D1Database, threshold: number = 85): Promise<any[]> {
  // This is a complex query that needs to be implemented
  // For now, we'll return a placeholder
  return [];
}
