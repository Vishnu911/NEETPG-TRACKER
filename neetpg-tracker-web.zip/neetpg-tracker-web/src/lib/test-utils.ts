// This script tests the functionality of the NEETPG/INICET tracker web application
// It checks database initialization, API endpoints, and core functionality

// Test database initialization
async function testDatabaseInit() {
  console.log('Testing database initialization...');
  try {
    const response = await fetch('/api/init', {
      method: 'POST',
    });
    
    if (!response.ok) {
      throw new Error(`Failed to initialize database: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to initialize database');
    }
    
    console.log('✅ Database initialization successful');
    return true;
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    return false;
  }
}

// Test subjects API
async function testSubjectsAPI() {
  console.log('Testing subjects API...');
  try {
    const response = await fetch('/api/subjects');
    
    if (!response.ok) {
      throw new Error(`Failed to fetch subjects: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to fetch subjects');
    }
    
    if (!Array.isArray(data.subjects) || data.subjects.length === 0) {
      throw new Error('No subjects returned from API');
    }
    
    console.log(`✅ Subjects API returned ${data.subjects.length} subjects`);
    return data.subjects[0].id; // Return first subject ID for further testing
  } catch (error) {
    console.error('❌ Subjects API test failed:', error);
    return null;
  }
}

// Test subject details API
async function testSubjectDetailsAPI(subjectId) {
  console.log(`Testing subject details API for subject ID ${subjectId}...`);
  try {
    const response = await fetch(`/api/subjects/${subjectId}`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch subject details: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to fetch subject details');
    }
    
    if (!data.subject || !data.subject.name) {
      throw new Error('Invalid subject data returned from API');
    }
    
    console.log(`✅ Subject details API returned subject: ${data.subject.name}`);
    return true;
  } catch (error) {
    console.error('❌ Subject details API test failed:', error);
    return false;
  }
}

// Test topics API
async function testTopicsAPI(subjectId) {
  console.log(`Testing topics API for subject ID ${subjectId}...`);
  try {
    const response = await fetch(`/api/topics?subjectId=${subjectId}`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch topics: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to fetch topics');
    }
    
    if (!Array.isArray(data.topics)) {
      throw new Error('Invalid topics data returned from API');
    }
    
    console.log(`✅ Topics API returned ${data.topics.length} topics`);
    return data.topics.length > 0 ? data.topics[0].id : null; // Return first topic ID for further testing
  } catch (error) {
    console.error('❌ Topics API test failed:', error);
    return null;
  }
}

// Test topic details API
async function testTopicDetailsAPI(topicId) {
  if (!topicId) {
    console.log('Skipping topic details API test (no topic ID available)');
    return false;
  }
  
  console.log(`Testing topic details API for topic ID ${topicId}...`);
  try {
    const response = await fetch(`/api/topics/${topicId}`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch topic details: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to fetch topic details');
    }
    
    if (!data.topic || !data.topic.name) {
      throw new Error('Invalid topic data returned from API');
    }
    
    console.log(`✅ Topic details API returned topic: ${data.topic.name}`);
    return true;
  } catch (error) {
    console.error('❌ Topic details API test failed:', error);
    return false;
  }
}

// Test adding a review
async function testAddReview(topicId) {
  if (!topicId) {
    console.log('Skipping add review test (no topic ID available)');
    return false;
  }
  
  console.log(`Testing add review API for topic ID ${topicId}...`);
  try {
    const reviewData = {
      topicId: parseInt(topicId, 10),
      correct: 3,
      wrong: 1,
      reviewDate: new Date().toISOString().split('T')[0]
    };
    
    const response = await fetch('/api/reviews', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(reviewData),
    });
    
    if (!response.ok) {
      throw new Error(`Failed to add review: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to add review');
    }
    
    console.log('✅ Successfully added review');
    return true;
  } catch (error) {
    console.error('❌ Add review test failed:', error);
    return false;
  }
}

// Test reviews API
async function testReviewsAPI(topicId) {
  if (!topicId) {
    console.log('Skipping reviews API test (no topic ID available)');
    return false;
  }
  
  console.log(`Testing reviews API for topic ID ${topicId}...`);
  try {
    const response = await fetch(`/api/reviews?topicId=${topicId}`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch reviews: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to fetch reviews');
    }
    
    if (!Array.isArray(data.reviews)) {
      throw new Error('Invalid reviews data returned from API');
    }
    
    console.log(`✅ Reviews API returned ${data.reviews.length} reviews`);
    return true;
  } catch (error) {
    console.error('❌ Reviews API test failed:', error);
    return false;
  }
}

// Test analysis API
async function testAnalysisAPI() {
  console.log('Testing analysis API...');
  try {
    const response = await fetch('/api/analysis');
    
    if (!response.ok) {
      throw new Error(`Failed to fetch analysis data: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data.success) {
      throw new Error(data.error || 'Failed to fetch analysis data');
    }
    
    if (!data.analysis || !data.analysis.subjects || !Array.isArray(data.analysis.subjects)) {
      throw new Error('Invalid analysis data returned from API');
    }
    
    console.log('✅ Analysis API returned valid data');
    return true;
  } catch (error) {
    console.error('❌ Analysis API test failed:', error);
    return false;
  }
}

// Run all tests
async function runAllTests() {
  console.log('Starting NEETPG/INICET Tracker Web Application Tests');
  console.log('=================================================');
  
  // Initialize database
  const dbInitSuccess = await testDatabaseInit();
  if (!dbInitSuccess) {
    console.error('Database initialization failed, stopping tests');
    return;
  }
  
  // Test subjects API
  const subjectId = await testSubjectsAPI();
  if (!subjectId) {
    console.error('Subjects API test failed, stopping tests');
    return;
  }
  
  // Test subject details API
  await testSubjectDetailsAPI(subjectId);
  
  // Test topics API
  const topicId = await testTopicsAPI(subjectId);
  
  // Test topic details API
  await testTopicDetailsAPI(topicId);
  
  // Test adding a review
  const reviewAdded = await testAddReview(topicId);
  
  // Test reviews API
  if (reviewAdded) {
    await testReviewsAPI(topicId);
  }
  
  // Test analysis API
  await testAnalysisAPI();
  
  console.log('=================================================');
  console.log('All tests completed');
}

// Export the test runner
export { runAllTests };
